//Define o pacote onde esta classe está localizada. Isso ajuda a organizar o código
// dentro do projeto.
package com.impacta.exercicio1

import android.os.Bundle // Necessário para salvar e restaurar o estado da atividade
import android.widget.Button // Permite usar botões na interface
import android.widget.EditText // Permite a entrada de texto pelo usuário
import android.widget.Toast // Exibe mensagens curtas na tela (notificações temporárias)
import androidx.appcompat.app.AppCompatActivity // Classe base para as atv que usam a ActionBar
import com.impacta.exercicio1.R //Refere-se ao arquivo de recursos R do projeto, usado para acessar
// IDs de elementos do layout


//Declara a classe MainActivity, que herda de AppCompatActivity, tornando-a
// uma atividade do Android.
class MainActivity : AppCompatActivity() {


//Metodo chamado quando a atividade é criada.
    override fun onCreate(savedInstanceState: Bundle?) {

        //Chama o metodo da superclasse para manter o comportamento padrão.
        super.onCreate(savedInstanceState)

        //Define qual layout XML será carregado
        setContentView(R.layout.activity_main)

        // Referências aos elementos do layout
       // Associa os botões ao código
        val emailInput = findViewById<EditText>(R.id.email_input)
        val senhaInput = findViewById<EditText>(R.id.senha_input)
        val loginButton = findViewById<Button>(R.id.login_button)
        val cadastroButton = findViewById<Button>(R.id.cadastro_button)

        // Configuração do botão de login
        loginButton.setOnClickListener {
            val email = emailInput.text.toString()
            val senha = senhaInput.text.toString()
            // Aqui você pode adicionar lógica para autenticação
            Toast.makeText(this, "Login: $email", Toast.LENGTH_SHORT).show()
        }

        // Configuração do botão de cadastro
        cadastroButton.setOnClickListener {
            // Aqui você pode adicionar lógica para redirecionar ou criar uma nova conta
            Toast.makeText(this, "Cadastro clicado", Toast.LENGTH_SHORT).show()
        }
    }
}
package com.impacta.calculadoradeaposentadoria

class LoginActivity {
}